#include "CollisionVolume.h"

using namespace NCL;
using namespace CSC3222;

CollisionVolume::CollisionVolume()
{
}


CollisionVolume::~CollisionVolume()
{
}
